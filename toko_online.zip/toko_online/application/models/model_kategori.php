<?php

class Model_kategori extends CI_Model{
    public function data_elektronik(){
        return $this->db->get_where("tg_barang",array('kategori' => 'elektronik'));
    }

    public function data_pakaian_pria(){
        $this->db->get_where("tg_barang",array('kategori' => 'pakaian pria'));
    }

    public function data_pakaian_wanita(){
        $this->db->get_where("tg_barang",array('kategori' => 'pakaian wanita'));
    }

    public function data_pakaian_anak_anak(){
        $this->db->get_where("tg_barang",array('kategori' => 'pakaian anak_anak'));
    }

    public function data_peralatan_olahraga(){
        $this->db->get_where("tg_barang",array('kategori' => 'peralatan olahraga'));
    }
}